:orphan:

.. _command-powerline-lint:

powerline-lint manual page
==========================

.. automan:: powerline.commands.lint
   :prog: powerline-lint

See also
--------

:manpage:`powerline(1)`, :manpage:`powerline-config(1)`
