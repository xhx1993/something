*************
Vim selectors
*************

.. automodule:: powerline.selectors.vim
   :members:
