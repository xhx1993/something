**************
Shell segments
**************

.. automodule:: powerline.segments.shell
   :members:
